#Import required library
from PIL import Image
import cv2

im = Image.open("./flower.jpg")

im.rotate(45).show()

imageFormat = im.format
print(im.size)
print("Image Format : "+''.join(imageFormat))

graScale = im.convert('L')
graScale.show()

blackAndWhiteImage = im.convert("1")
blackAndWhiteImage.show()

imageWithColorPalette = im.convert("P", palette=Image.ADAPTIVE, colors=8)
imageWithColorPalette.show()


im.thumbnail((300, 300))
im.show()

image = cv2.imread("./flower.jpg", cv2.IMREAD_GRAYSCALE)
cv2.imshow('image',image)
cv2.waitKey(0)
cv2.destroyAllWindows()
